package com.example.notify;

import androidx.fragment.app.Fragment;

public class fragmentfriendrequest extends Fragment {
}
