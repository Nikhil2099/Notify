package com.example.notify;

public class uploaduserdatajavaclass {
    public String username,password;

    public uploaduserdatajavaclass(String Username, String password) {

    }
}
