package com.example.notify;

public class uploaduserdataclass {
    public String username,password,city;
    public Integer phNo;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getPhNo() {
        return phNo;
    }

    public void setPhNo(Integer phNo) {
        this.phNo = phNo;
    }

    public uploaduserdataclass(String username, String password, String city, Integer phNo) {
        this.username = username;
        this.password = password;
        this.city = city;
        this.phNo = phNo;
    }

    public uploaduserdataclass(String username, String password, String city) {
        this.username = username;
        this.password = password;
        this.city = city;
    }

    public uploaduserdataclass() {
    }
}
